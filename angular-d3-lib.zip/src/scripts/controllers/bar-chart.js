app.controller("barChartController", ["$scope", function($scope){
	$scope.data = [
		{name: "Greg", score: 300},
		{name: "Ari", score: 96},
		{name: 'Q', score: 75},
		{name: "Loser", score: 48}
	];
}]);